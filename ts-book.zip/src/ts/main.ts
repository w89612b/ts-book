/*引入tsd模块*/
///<reference path="./references.d.ts" />